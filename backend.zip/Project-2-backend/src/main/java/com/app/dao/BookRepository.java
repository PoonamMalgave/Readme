package com.app.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.app.pojos.Book;

public interface BookRepository extends JpaRepository<Book, Integer>{

	@Query("from Book b where b.quantity > 0")
	List<Book> findByUsingQty();
	
	//select * from book where b_name like 'meluha%';
	//@Query("SELECT m FROM Movie m WHERE m.title LIKE %:title%")
	
	@Query("SELECT b FROM Book b WHERE b.bName LIKE %:bName%")
	List<Book> searchByBookName(@Param("bName") String bName);
	
	
	// @Query("select c from Country c where c.name != :name")
	@Query("SELECT b FROM Book b WHERE b.offer > 0 and b.quantity > 0")
	List<Book> searchByOffer();
	
	//@Query("delete from Book b where b.id=:bookId")
	//String deleteById(@Param("bookId")int bookId);
}
