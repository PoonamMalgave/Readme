package com.app.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.app.pojos.Order;

public interface OrderRepository extends JpaRepository<Order, Integer>{

	//@Query("SELECT b FROM Book b WHERE b.offer > 0 and b.quantity > 0")
	//List<Book> searchByOffer();
	//@Query("delete from Book b where b.id=:bookId")
	//String deleteById(@Param("bookId")int bookId);
	//
	
	@Query("from Order o where o.totalBill > 0 and o.customer.id =:id and o.status=:status")
	List<Order> findByUsingBill(@Param("id") int custId, @Param("status") String status);
}
