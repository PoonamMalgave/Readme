package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.app.pojos.Book;
import com.app.service.IBookService;

@RestController
@RequestMapping("/Book")
@CrossOrigin
public class BookController {

	@Autowired
	private IBookService bookService;
	
	public BookController() {
		super();
		System.out.println("Book Controller : def constructor");
	}

	@GetMapping("/qty")
	public ResponseEntity<?> getAllBooksUsingQty() {
		return bookService.getAllBooksUsingQty();
	}

	@GetMapping
	public ResponseEntity<?> getAllBooks() {
		return bookService.getAllBooks();
	}

	@GetMapping("/{bookId}")
	public ResponseEntity<?> getBookByID(@PathVariable int bookId) {
		return bookService.getBookByID(bookId);
	}
	
	@GetMapping("/bookName/{bName}")
	public ResponseEntity<?> getBookByName(@PathVariable String bName) {
		return bookService.getBookByName(bName);
	}

	@GetMapping("/offers")
	public ResponseEntity<?> getOfferedBook() {
		return bookService.getOfferedBook();
	}

	@GetMapping("/vendor/{vendorId}")
	public ResponseEntity<?> getBookByVendorID(@PathVariable int vendorId) {
		return bookService.getBookByVendorID(vendorId);
	}

	// Adding duplicate values of book in hashSet
	// MultipartFile
	@PostMapping
	public ResponseEntity<?> addNewBook(@RequestBody Book book) {
		return bookService.addNewBook(book);
	}

	@PutMapping(value = "/upload/{bookId}", consumes = { "multipart/form-data" })
	public ResponseEntity<?> addImageToBook(@PathVariable int bookId, @RequestParam("myFile") MultipartFile imageFile) {
		return bookService.addImageToBook(bookId, imageFile);
	}

	@GetMapping("/images/{bookId}")
	public ResponseEntity<byte[]> getFile(@PathVariable Integer bookId) {
		return bookService.getFile(bookId);
	}

	@PutMapping("/{bookId}")
	public ResponseEntity<?> updateBookDetails(@PathVariable int bookId, @RequestBody Book details) {
		return bookService.updateBookDetails(bookId, details);
	}

	@DeleteMapping("/{bookId}")
	public ResponseEntity<?> removeBook(@PathVariable int bookId) {
		return bookService.removeBook(bookId);
	}

}
