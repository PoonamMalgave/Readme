package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.Customer;
import com.app.pojos.CustomerAddress;
import com.app.service.ICustomerService;

@RestController
@RequestMapping("/Customer")
@CrossOrigin
public class CustomerController {

	@Autowired
	private ICustomerService custService;
	
	
	public CustomerController() {
		super();
		System.out.println("In def constructor of "+ getClass().getName());
	}
	
	//working fine
	@GetMapping
	public ResponseEntity<?> getAllCustomers(){
		return custService.getAllCustomers();
	}
	
	//working fine
	@GetMapping("/{custId}")
	public ResponseEntity<?> getCustomerById(@PathVariable int custId) {
		return custService.getCustomerById(custId);
	}
	
	//this is to create only one order for a customer untill he checks out
	@GetMapping("/orderid/{custId}")
	public ResponseEntity<?> getOrderId(@PathVariable int custId) {
		return custService.getOrderId(custId);
	}
	
	@PutMapping("/login") 
	public ResponseEntity<?> getCustomerByEmailPassword(@RequestBody Customer custDetails) { 
		return custService.getCustomerByEmailPassword(custDetails);
	}
	
	//working fine
	@PostMapping
	public ResponseEntity<?> addNewCustomer(@RequestBody Customer custDetails) {
		return custService.addNewCustomer(custDetails);
	}
	
	//working fine 
	@PutMapping("/{custId}")
	public ResponseEntity<?> updateCustomerDetails(@PathVariable int custId, @RequestBody Customer details) {
		return custService.updateCustomerDetails(custId, details);
	}
	
	@PutMapping("/address/{custId}")
	public ResponseEntity<?> addCustomerAddress(@PathVariable int custId, @RequestBody CustomerAddress address) {
		return custService.addCustomerAddress(custId, address);
	}
	
	//working fine
	@DeleteMapping("/{custId}")
	public ResponseEntity<?>  removeCustomerById(@PathVariable int custId) {
		return custService.removeCustomerById(custId);
	}

}
