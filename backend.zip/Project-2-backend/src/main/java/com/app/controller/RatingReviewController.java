package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.RatingAndReview;
import com.app.service.IRatingService;

@RestController
@RequestMapping("/Rating")
@CrossOrigin
public class RatingReviewController {

	@Autowired
	private IRatingService rateService;

	public RatingReviewController() {
		super();
		System.out.println("RatingReview Controller : def constructor");
	}
	
	@GetMapping
	public ResponseEntity<?> getAllRating(){
		return rateService.getAllRating();
	}
	
	@GetMapping("/{ratingId}")
	public ResponseEntity<?> getRatingByID (@PathVariable int ratingId) {
		return rateService.getRatingByID(ratingId);
	}
	
	@GetMapping("/book/{bookId}")
	public ResponseEntity<?> getRatingByBookID (@PathVariable int bookId) {
		return rateService.getRatingByBookID(bookId);
	}
	
	@GetMapping("/highRated")
	public ResponseEntity<?> getHighestRatedBook () {
		return rateService.getHighestRatedBook();
	}
	
	@PostMapping
	public ResponseEntity<?> addNewReview (@RequestBody RatingAndReview review) {
		return rateService.addNewReview(review);
	}
	
	@PutMapping("/{ratingId}")
	public ResponseEntity<?> updateRatingByID (@PathVariable int ratingId, @RequestBody RatingAndReview rating) {
		return rateService.updateRatingByID(ratingId, rating);
	}
	
	@DeleteMapping("/{ratingId}")
	public ResponseEntity<?> removeRating (@PathVariable int ratingId) {
		return rateService.removeRating(ratingId);
	}
	
}
