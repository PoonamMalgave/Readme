package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.BusinessDetails;
import com.app.pojos.Vendor;
import com.app.pojos.VendorAddress;
import com.app.service.IVendorService;

@RestController
@RequestMapping("/Vendor")
@CrossOrigin
public class VendorController {

	@Autowired
	private IVendorService vendorService;
	
	public VendorController() {
		super();
		System.out.println("In def constructor of "+ getClass().getName());
	}
	
	@GetMapping
	public ResponseEntity<?> getAllVendor() {
		return vendorService.getAllVendor();
	}
	
	@GetMapping("/{vendorId}")
	public ResponseEntity<?> getVendorByID (@PathVariable int vendorId) {
		return vendorService.getVendorByID(vendorId);
	}
	
	@PostMapping
	public ResponseEntity<?> addNewVendor(@RequestBody Vendor vendor) {
		return vendorService.addNewVendor(vendor);
	}

	@PutMapping("/login") 
	public ResponseEntity<?> getVendorByEmailPassword(@RequestBody Vendor details) { 
		return vendorService.getVendorByEmailPassword(details);
	}
	
	@PutMapping("/{vendorId}")
	public ResponseEntity<?> updateVendor(@PathVariable int vendorId, @RequestBody Vendor vendor) {
		return vendorService.updateVendor(vendorId, vendor);
	}
	
	@PutMapping("/business/{vendorId}")
	public ResponseEntity<?> addVendorBusiness(@PathVariable int vendorId, @RequestBody BusinessDetails details) {
		return vendorService.addVendorBusiness(vendorId, details);
	}
	
	@PutMapping("/address/{vendorId}")
	public ResponseEntity<?> addVendorAddress(@PathVariable int vendorId, @RequestBody VendorAddress address) {
		return vendorService.addVendorAddress(vendorId, address);
	}
	
	
	@DeleteMapping("/{vendorId}")
	public ResponseEntity<?> removeVendor(@PathVariable int vendorId) {
		return vendorService.removeVendor(vendorId);
	}
	
	
}

