package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.app.pojos.Order;
import com.app.pojos.OrderList;
import com.app.service.IOrderListService;

@RestController
@RequestMapping("/OrderList")
@CrossOrigin
public class OrderListController {

	@Autowired
	private IOrderListService orderListService;
	
	public OrderListController() {
		super();
		System.out.println("OrderList Controller : def constructor");
	}
	
	@GetMapping
	public ResponseEntity<?> getAllOrderList() {
		return orderListService.getAllOrderList();
	}
	
	@GetMapping("/{orderListId}")
	public ResponseEntity<?> getOrderListByID (@PathVariable int orderListId) {
		return orderListService.getOrderListByID(orderListId);
	}
	
	@GetMapping("/book/{bookId}")
	public ResponseEntity<?> getOrderListByBookID (@PathVariable int bookId) {
		return orderListService.getOrderListByBookID(bookId);
	}
	
	//shows all order list with same order Id 
	@GetMapping("/order/{orderId}")
	public ResponseEntity<?> getOrderListByOrderID (@PathVariable int orderId) {
		return orderListService.getOrderListByOrderID(orderId);
	}
	
	//adds new order list in already existing order calculates total bill 
	@PostMapping
	public ResponseEntity<?> newOrderList(@RequestBody OrderList order) {
		return orderListService.newOrderList(order);
	}
	
	@PutMapping("/{orderId}")
	public ResponseEntity<?> updateOrderList(@PathVariable int orderId, @RequestBody OrderList order) {
		return orderListService.updateOrderList(orderId, order);
	}
	
	@DeleteMapping("/{orderId}")
	public ResponseEntity<?> removeOrderList(@PathVariable int orderId) {
		return orderListService.removeOrderList(orderId);
	}
	
	//checking book status if available place order otherwise dont
	//updates book tables quantity too
	public ResponseEntity<?> orderPlaced(Order order) {
		return orderListService.orderPlaced(order);
	}
	
}
