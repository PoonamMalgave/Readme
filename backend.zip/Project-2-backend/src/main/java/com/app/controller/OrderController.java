package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.Order;
import com.app.service.IOrderService;

@RestController
@RequestMapping("/Order")
@CrossOrigin
public class OrderController {

	@Autowired
	private IOrderService orderService;

	public OrderController() {
		super();
		System.out.println("Order Controller : def constructor");
	}
	
	@GetMapping
	public ResponseEntity<?> getAllOrder() {
		return orderService.getAllOrder();
	}
	
	@GetMapping("/{orderId}")
	public ResponseEntity<?> getOrderByID (@PathVariable int orderId) {
		return orderService.getOrderByID(orderId);
	}
	
	@GetMapping("/customer/{custId}")
	public ResponseEntity<?> getOrderByCustID (@PathVariable int custId) {
		return orderService.getOrderByCustID(custId);
	}
	
	//creates new order just by input ---> customer id
	@PostMapping
	public ResponseEntity<?> newOrder(@PathVariable int custId) {
		return orderService.newOrder(custId);
	}
	
	//checks order status and places the order
	@PutMapping("/{orderId}")
	public ResponseEntity<?> updateOrder(@PathVariable int orderId, @RequestBody Order order) {
		return orderService.updateOrder(orderId, order);
	}
	
	//to remove order
	@DeleteMapping("/{orderId}")
	public ResponseEntity<?> removeOrder(@PathVariable int orderId) {
		return orderService.removeOrder(orderId);
	}
	
	//calculates total order bill & doesn't updates order status
	@PutMapping("/order/{orderId}")
	public ResponseEntity<?> updateTotalBill(@PathVariable int orderId, @RequestBody Order order) {
		return orderService.updateTotalBill(orderId, order);
	}
}
