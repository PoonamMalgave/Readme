package com.app.service;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.app.pojos.Book;

public interface IBookService {

	ResponseEntity<?> getAllBooksUsingQty();
	
	ResponseEntity<?> getAllBooks();
	
	ResponseEntity<?> getBookByID(int bookId);
	
	ResponseEntity<?> getBookByName(String bName);

	ResponseEntity<?> getOfferedBook();
	
	ResponseEntity<?> getBookByVendorID(int vendorId);
	
	ResponseEntity<?> addNewBook(Book book);
	
	ResponseEntity<?> addImageToBook(int bookId, MultipartFile imageFile);
	
	ResponseEntity<byte[]> getFile(Integer bookId);

	ResponseEntity<?> updateBookDetails(int bookId, Book details);

	ResponseEntity<?> removeBook(int bookId);
	
	
}
