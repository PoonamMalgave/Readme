package com.app.service;

import org.springframework.http.ResponseEntity;

import com.app.pojos.BusinessDetails;
import com.app.pojos.Vendor;
import com.app.pojos.VendorAddress;

public interface IVendorService {

	ResponseEntity<?> getAllVendor();
	
	ResponseEntity<?> getVendorByID (int vendorId);
	
	ResponseEntity<?> addNewVendor(Vendor vendor);

	ResponseEntity<?> getVendorByEmailPassword(Vendor details);

	ResponseEntity<?> updateVendor(int vendorId, Vendor vendor);

	ResponseEntity<?> addVendorBusiness(int vendorId, BusinessDetails details);

	ResponseEntity<?> addVendorAddress(int vendorId, VendorAddress address);
	
	ResponseEntity<?> removeVendor(int vendorId);
	
}
