package com.app.service;

import org.springframework.http.ResponseEntity;

import com.app.pojos.Customer;
import com.app.pojos.CustomerAddress;

public interface ICustomerService {

	ResponseEntity<?> getAllCustomers();
	
	ResponseEntity<?> getCustomerById(int custId);
	
	ResponseEntity<?> getOrderId(int custId);

	ResponseEntity<?> getCustomerByEmailPassword(Customer custDetails);

	ResponseEntity<?> addNewCustomer(Customer custDetails);
	
	ResponseEntity<?> updateCustomerDetails(int custId, Customer details);

	ResponseEntity<?> addCustomerAddress(int custId, CustomerAddress address);
	
	ResponseEntity<?>  removeCustomerById(int custId);

	
	
}
