package com.app.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.CustomerRepository;
import com.app.dto.Email;
import com.app.dto.ResponseDTO;
import com.app.dto.ResponseListDTO;
import com.app.pojos.Customer;
import com.app.pojos.CustomerAddress;
import com.app.pojos.Order;

@Service
@Transactional
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	private CustomerRepository custRepo;
	@Autowired
	private IOrderService orderService;
	@Autowired 
	private MailService mailService;
	
	@Override
	public ResponseEntity<?> getAllCustomers() {
		List<Customer> customers=custRepo.findAll();
		return new ResponseEntity<>(new ResponseListDTO("success","Customer Found",customers),HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getCustomerById(int custId) {
		Optional<Customer> optional=custRepo.findById(custId);
		if(optional.isPresent())
			return new ResponseEntity<>(new ResponseDTO("success","Details Found",optional.get()),HttpStatus.OK);
		
		return new ResponseEntity<>(new ResponseDTO("error","Customer id not Found",null),HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseEntity<?> getOrderId(int custId) {
		Optional<Customer> optional=custRepo.findById(custId);
		if(optional.isPresent()) {
			Customer cust=optional.get();
			
			List<Order> orders=cust.getOrders();
			for(int i=0; i<orders.size(); i++) {
				if(orders.get(i).getStatus().equals("Not Yet Checked Out!")) {
					return new ResponseEntity<>(new ResponseDTO("success","Details Found",orders.get(i)),HttpStatus.OK);
				} 
			}
			return new ResponseEntity<>(new ResponseDTO("success","Details Found",orderService.newOrder(custId)),HttpStatus.OK);
		}
		return new ResponseEntity<>(new ResponseDTO("error","Customer id not Found",null),HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseEntity<?> getCustomerByEmailPassword(Customer custDetails) {
		System.out.println("Customer Controller : get login " + custDetails.getEmail());
		Optional<Customer> cust=custRepo.findByEmailAndPassword(custDetails.getEmail(), custDetails.getPassword());
		if(cust.isPresent()) {
			Customer c=cust.get();
			this.getOrderId(c.getId());
			return new ResponseEntity<>(new ResponseDTO("success","Details Found",c),HttpStatus.OK);
		}
		return new ResponseEntity<>(new ResponseDTO("error","Customer not Found",null),HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseEntity<?> addNewCustomer(Customer custDetails) {
		try {
			Email email =new Email();
			email.setDestEmail(custDetails.getEmail());
			System.out.println("Mentioned email : " + custDetails.getEmail());
			email.setSubject("Customer Registration Successful");
			email.setMessage("Welcome to eBookStore shop! \nlearning should never stop! \nYou have successfully registered and logged in in our website. \nPlease Check  Your Login Details Mentioned Below : \nEmail:"+custDetails.getEmail()+"\nPassword::"+custDetails.getPassword()
			+"\n\n\nKeep reading, Happy Shopping!");
			mailService.sendEmail(email);
			custDetails.setJoiningDate(LocalDate.now());
			return new ResponseEntity<>(new ResponseDTO("success","Details Found",custRepo.save(custDetails)),HttpStatus.OK);

		} catch (RuntimeException e) {
			System.out.println("Got Exception!!!\n"+ e.getMessage());
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public ResponseEntity<?> updateCustomerDetails(int custId, Customer details) {
		System.out.println("Customer Controller : In update Request");
		Optional<Customer> optional=custRepo.findById(custId);
		if(optional.isPresent()) {
			Customer c=optional.get();
			c.setFirstName(details.getFirstName());
			c.setLastName(details.getLastName());
			c.setMobileNo(details.getMobileNo());
			c.setPassword(details.getPassword());
			return new ResponseEntity<>(new ResponseDTO("success","Details Found",custRepo.save(c)),HttpStatus.OK);
		}
		return new ResponseEntity<>(new ResponseDTO("error","Customer id not Found",null),HttpStatus.NOT_FOUND);

	}

	@Override
	public ResponseEntity<?> addCustomerAddress(int custId, CustomerAddress address) {
		System.out.println("Update Customer Address : custId : " + custId);
		System.out.println("address : " + address);
		Optional<Customer> optional=custRepo.findById(custId);
		if(optional.isPresent()) {
			Customer c=optional.get();
			c.setAddress(address);
			return new ResponseEntity<>(new ResponseDTO("success","Details Found",custRepo.save(c)),HttpStatus.OK);
		}
		return new ResponseEntity<>(new ResponseDTO("error","Customer id not Found",null),HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseEntity<?> removeCustomerById(int custId) {
		System.out.println("1. Deleteing customer : "+custId);
		Optional<Customer> optional=custRepo.findById(custId);
		if(optional.isPresent()) {
			Customer cust=optional.get();
			
			System.out.println("2. cust -- order side : ");
			List<Order> list = cust.getOrders();
			list.forEach((l) -> {
				orderService.removeOrder(l.getId());
			});
			
			System.out.println("3. Doing : ");
			custRepo.deleteById(custId);
			System.out.println("Customer Deleted Successfully!");
			return new ResponseEntity<>("Customer removed successfully!", HttpStatus.OK);
		}
		return new ResponseEntity<>(new ResponseDTO("error","Customer id not Found",null),HttpStatus.NOT_FOUND);
	}

}
