package com.app.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.CustomerRepository;
import com.app.dao.OrderListRepository;
import com.app.dao.OrderRepository;
import com.app.dto.ResponseDTO;
import com.app.dto.ResponseListDTO;
import com.app.pojos.Customer;
import com.app.pojos.Order;
import com.app.pojos.OrderList;

@Service
@Transactional
public class OrderServiceImpl implements IOrderService {

	@Autowired
	private OrderRepository orderRepo;
	@Autowired
	private OrderListRepository listRepo;
	@Autowired
	private IOrderListService listService;
	@Autowired
	private CustomerRepository custRepo;
	
	@Override
	public ResponseEntity<?> getAllOrder() {
		List<Order> orders=orderRepo.findAll();
		return new ResponseEntity<>(new ResponseListDTO("success","Customer Found",orders),HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getOrderByID(int orderId) {
		Optional<Order> optional=orderRepo.findById(orderId);
		if(optional.isPresent())
			return new ResponseEntity<>(new ResponseDTO("success","Details Found",optional.get()),HttpStatus.OK);
		
		return new ResponseEntity<>(new ResponseDTO("error","Order id not Found",null),HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseEntity<?> getOrderByCustID(int custId) {
		Optional<Customer> optional=custRepo.findById(custId);
		if(optional.isPresent()) {
			List<Order> o = orderRepo.findByUsingBill(custId,"Checked Out successfully!");
			return new ResponseEntity<>(new ResponseDTO("success","Details Found",o),HttpStatus.OK);
		}
		return new ResponseEntity<>(new ResponseDTO("error","Order id not Found",null),HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseEntity<?> newOrder(int custId) {
		Order order= new Order();
		Optional<Customer> optional=custRepo.findById(custId);
		if(optional.isPresent()) {
			Customer cust=optional.get();
			order.setCustomer(cust);
			order.setStatus("Not Yet Checked Out!");
			order.setOrderDate(LocalDate.now());
		}
		return new ResponseEntity<>(new ResponseDTO("success","Details Found",orderRepo.save(order)), HttpStatus.CREATED);
	}

	@Override
	public ResponseEntity<?> updateOrder(int orderId, Order order) {
		System.out.println("1. Final order controller : " + orderId +" : "+ order.getStatus());
		Optional<Order> optional=orderRepo.findById(orderId);
		if(optional.isPresent()) {
			Order o=optional.get();
			o.setOrderDate(LocalDate.now());
			o.setStatus(order.getStatus());
			
			if(order.getStatus().equals("Checked Out successfully!")) {
				listService.orderPlaced(o);
				
				if(o.getStatus().equals("Checked Out successfully!")) 
					System.out.println("Order confirmed!");
				else
					return new ResponseEntity<>(new ResponseDTO("error","Can Not place the order",null),HttpStatus.NOT_FOUND);
			}
			
			orderRepo.save(o);
			return new ResponseEntity<>(new ResponseDTO("Success", "Details found", o), HttpStatus.OK);
		}
		return new ResponseEntity<>(new ResponseDTO("error","Order id not Found",null),HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseEntity<?> removeOrder(int orderId) {
		System.out.println("1. Deleting order : ");
		Optional<Order> optional=orderRepo.findById(orderId);
		if(optional.isPresent()) {
			Order order=optional.get();
			
			//check the date
			if(order.getOrderDate().equals(LocalDate.now())) {
			
			System.out.println("2. order ---- list ");
			Set<OrderList> list= order.getOrderList();
			
			List<Integer> id=new ArrayList<>();
			//to avoid ConcurrentModificationException 
			
			list.forEach((l) -> {
				id.add(l.getId());
			});
			
			id.forEach((i)-> {
				listService.removeOrderList(i);
			});
			
			order.setStatus("Cancelled!");
			
			System.out.println("3. order ---- cust ");
			Customer cust=order.getCustomer();
			cust.getOrders().remove(order);
			custRepo.save(cust);
			
			System.out.println("Order deleted successfully!");
			return new ResponseEntity<>("Order removed successfully!", HttpStatus.OK);
			} else
				return new ResponseEntity<>(new ResponseDTO("error","Can not cancel the order!",null),HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(new ResponseDTO("error","Order id not Found",null),HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseEntity<?> updateTotalBill(int orderId, Order order) {
		System.out.println("Final order controller : " + orderId +" : "+ order.getStatus());
		Optional<Order> optional=orderRepo.findById(orderId);
		if(optional.isPresent()) {
			Order o=optional.get();
			o.setOrderDate(LocalDate.now());
			
			Set<OrderList> list = o.getOrderList();
			o.setTotalBill(0.0);
			list.forEach((orderLists) -> {
				int id=orderLists.getId();
				Optional<OrderList> optionalList=listRepo.findById(id);
				if(optionalList.isPresent()) {
					OrderList tempList=optionalList.get();
					o.calTotalOrderBill(tempList);
				}
			});
			return new ResponseEntity<>(new ResponseDTO("Success","details found",orderRepo.save(o)), HttpStatus.OK);
		}
		return new ResponseEntity<>(new ResponseDTO("error","Order id not Found",null),HttpStatus.NOT_FOUND);
	}

}
