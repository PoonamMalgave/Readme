package com.app.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.BookRepository;
import com.app.dao.RatingAndReviewRepository;
import com.app.dto.ResponseDTO;
import com.app.dto.ResponseListDTO;
import com.app.pojos.Book;
import com.app.pojos.RatingAndReview;

@Service
@Transactional
public class RatingServiceImpl implements IRatingService {

	@Autowired
	private RatingAndReviewRepository ratingRepo;
	@Autowired
	private BookRepository bookRepo;
	
	@Override
	public ResponseEntity<?> getAllRating() {
		List<RatingAndReview> ratings=ratingRepo.findAll();
		return new ResponseEntity<>(new ResponseListDTO("success","Customer Found",ratings),HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getRatingByID(int ratingId) {
		Optional<RatingAndReview> optional=ratingRepo.findById(ratingId);
		if(optional.isPresent()) {
			return new ResponseEntity<>(new ResponseDTO("Success","Rating id Found",optional.get()), HttpStatus.OK);
		}
		return new ResponseEntity<>(new ResponseDTO("error","Rating id not Found",null),HttpStatus.NOT_FOUND);
	
	}

	@Override
	public ResponseEntity<?> getRatingByBookID(int bookId) {
		Optional<Book> optional=bookRepo.findById(bookId);
		if(optional.isPresent()) {
			Book b=optional.get();
			return new ResponseEntity<>(new ResponseDTO("Success","Book id Found",b.getRatingReview()), HttpStatus.OK);
		}
		return new ResponseEntity<>(new ResponseDTO("error","Book id not Found",null),HttpStatus.NOT_FOUND);
	
	}

	@Override
	public ResponseEntity<?> getHighestRatedBook() {
		System.out.println("1 Getting highest rated book!!!");
		List<RatingAndReview> ratings=ratingRepo.getHighestRatedBook();
			return new ResponseEntity<>(new ResponseDTO("Success","Highest rated book found",ratings), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> addNewReview(RatingAndReview review) {
		System.out.println("Add new review!!!");
		int bookId = review.getBook().getId();
			Optional<Book> optional=bookRepo.findById(bookId);
			if(optional.isPresent()) {
				Book b=optional.get();
				review.setDate(LocalDate.now());
				b.getRatingReview().add(review);
				return new ResponseEntity<>(new ResponseDTO("Success","Book id found",bookRepo.save(b)), HttpStatus.CREATED);
			}
			return new ResponseEntity<>(new ResponseDTO("error","Book id not Found",null),HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseEntity<?> updateRatingByID(int ratingId, RatingAndReview rating) {
		Optional<RatingAndReview> optional=ratingRepo.findById(ratingId);
		if(optional.isPresent()) {
			RatingAndReview r=optional.get();
			r.setRating(rating.getRating());
			r.setReview(rating.getReview());
			r.setDate(LocalDate.now());
			return new ResponseEntity<>(new ResponseDTO("Success","Book id found",ratingRepo.save(r)), HttpStatus.CREATED);
		}
		return new ResponseEntity<>(new ResponseDTO("error","Rating id not Found",null),HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseEntity<?> removeRating(int ratingId) {
		Optional<RatingAndReview> optional=ratingRepo.findById(ratingId);
		if(optional.isPresent()) {
			ratingRepo.deleteById(ratingId);
			return new ResponseEntity<>("Rating removed successfully!", HttpStatus.OK);
		}
		return new ResponseEntity<>(new ResponseDTO("error","Rating id not Found",null),HttpStatus.NOT_FOUND);
	}

}
