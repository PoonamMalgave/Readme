package com.app.service;

import org.springframework.http.ResponseEntity;

import com.app.pojos.Order;

public interface IOrderService {

	ResponseEntity<?> getAllOrder();
	
	ResponseEntity<?> getOrderByID (int orderId);

	ResponseEntity<?> getOrderByCustID (int custId);

	ResponseEntity<?> newOrder(int custId);

	ResponseEntity<?> updateOrder(int orderId, Order order);

	ResponseEntity<?> removeOrder(int orderId);

	ResponseEntity<?> updateTotalBill(int orderId, Order order);
}
