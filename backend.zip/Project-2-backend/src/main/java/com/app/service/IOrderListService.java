package com.app.service;

import org.springframework.http.ResponseEntity;

import com.app.pojos.Order;
import com.app.pojos.OrderList;

public interface IOrderListService {

	ResponseEntity<?> getAllOrderList();
	
	ResponseEntity<?> getOrderListByID (int orderListId);
	
	ResponseEntity<?> getOrderListByBookID (int bookId);
	
	ResponseEntity<?> getOrderListByOrderID (int orderId);

	ResponseEntity<?> newOrderList(OrderList order);

	ResponseEntity<?> updateOrderList(int orderId, OrderList order);
	
	ResponseEntity<?> removeOrderList(int orderId);

	ResponseEntity<?> orderPlaced(Order order);


}
