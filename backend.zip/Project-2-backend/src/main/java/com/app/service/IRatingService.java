package com.app.service;

import org.springframework.http.ResponseEntity;

import com.app.pojos.RatingAndReview;

public interface IRatingService {

	ResponseEntity<?> getAllRating();
	
	ResponseEntity<?> getRatingByID(int ratingId);

	ResponseEntity<?> getRatingByBookID(int bookId);
	
	ResponseEntity<?> getHighestRatedBook();
	
	ResponseEntity<?> addNewReview(RatingAndReview review);
	
	ResponseEntity<?> updateRatingByID(int ratingId, RatingAndReview rating);

	ResponseEntity<?> removeRating(int ratingId); 

}
