package com.app.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.app.customException.ResourceNotFoundException;
import com.app.dao.BookRepository;
import com.app.dao.VendorRepository;
import com.app.dto.ResponseDTO;
import com.app.dto.ResponseListDTO;
import com.app.pojos.Book;
import com.app.pojos.OrderList;
import com.app.pojos.RatingAndReview;
import com.app.pojos.Vendor;

@Service
@Transactional
public class BookServiceImpl implements IBookService {

	@Autowired
	private BookRepository bookRepo;
	@Autowired
	private VendorRepository vendorRepo;
	@Autowired
	private IOrderListService listService;
	@Autowired
	private IRatingService ratingService;
	
	@Override
	public ResponseEntity<?> getAllBooksUsingQty() {
		List<Book> books = bookRepo.findByUsingQty();
		return new ResponseEntity<>(new ResponseListDTO("success","Book Found",books),HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getAllBooks() {
		List<Book> books = bookRepo.findAll();
		return new ResponseEntity<>(new ResponseListDTO("success","Book Found",books),HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getBookByID(int bookId) {
		System.out.println("Controller : Book Id : " + bookId);
		Optional<Book> optional = bookRepo.findById(bookId);
		if (optional.isPresent())
			return new ResponseEntity<>(new ResponseDTO("success", "Details Found", optional.get()), HttpStatus.OK);

		return new ResponseEntity<>(new ResponseDTO("error", "Book id not Found", null), HttpStatus.NOT_FOUND);

	}

	@Override
	public ResponseEntity<?> getBookByName(String bName) {
		System.out.println("Controller : Book Id : " + bName);
		List<Book> books = bookRepo.searchByBookName(bName);
		return new ResponseEntity<>(new ResponseListDTO("success","Book Found",books),HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getOfferedBook() {
		System.out.println("Controller : Offered Books ");
		List<Book> books = bookRepo.searchByOffer();
		return new ResponseEntity<>(new ResponseListDTO("success","Book Found",books),HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getBookByVendorID(int vendorId) {
		System.out.println("Controller : vendor Id : " + vendorId);
		Optional<Vendor> optional = vendorRepo.findById(vendorId);
		if (optional.isPresent()) {
			Vendor v = optional.get();
			return new ResponseEntity<>(new ResponseDTO("success", "Details Found", v.getBooks()), HttpStatus.OK);
		}
		return new ResponseEntity<>(new ResponseDTO("error", "Book id not Found", null), HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseEntity<?> addNewBook(Book book) {
		int vendorId = book.getVendor().getId();
		System.out.println("In book controller : " + vendorId);
		Optional<Vendor> optional = vendorRepo.findById(vendorId);
		if (optional.isPresent()) {
			Vendor v = optional.get();
			book.setUploadingDate(LocalDate.now());
			v.getBooks().add(book);
			return new ResponseEntity<>(new ResponseDTO("success", "Details Found", vendorRepo.save(v)), HttpStatus.CREATED);
		}
		return new ResponseEntity<>(new ResponseDTO("error", "Vendor id not Found", null), HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseEntity<?> addImageToBook(int bookId, MultipartFile imageFile) {
		System.out.println("1. Book id : " + bookId);
		System.out.println("2. uploading image name : " + imageFile.getOriginalFilename());
		System.out.println("3. name : " + imageFile.getName());
		System.out.println("4. size : " + imageFile.getSize());
		System.out.println("4. size : " + imageFile);

		try {
			Optional<Book> optional = bookRepo.findById(bookId);
			if (optional.isPresent()) {

				Book b = optional.get();

				b.setImage(imageFile.getBytes());
				b.setFileName(imageFile.getOriginalFilename());

				bookRepo.save(b);

				System.out.println("6. Done!!!");
				return new ResponseEntity<>(b.getImage(), HttpStatus.CREATED);
			}
			return new ResponseEntity<>(new ResponseDTO("error", "Book id not Found", null), HttpStatus.NOT_FOUND);

		} catch (Exception e) {
			System.out.println("Caused Error : ");
			e.printStackTrace();
		}
		return new ResponseEntity<>(new ResponseDTO("error", "Book id not Found", null), HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseEntity<byte[]> getFile(Integer bookId) {
		System.out.println("in get file " + bookId);
		Book b = bookRepo.findById(bookId).orElseThrow(() -> new ResourceNotFoundException("book not found"));

		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + b.getFileName() + "\"")
				.body(b.getImage());
	}

	@Override
	public ResponseEntity<?> updateBookDetails(int bookId, Book details) {
		System.out.println("Book Controller : In update Request : book Id : " + bookId);
		Optional<Book> optional = bookRepo.findById(bookId);
		if (optional.isPresent()) {
			Book b = optional.get();
			b.setbName(details.getbName());
			b.setAuthor(details.getAuthor());
			b.setCategory(details.getCategory());
			b.setDescription(details.getDescription());
			b.setFormat(details.getFormat());
			b.setLangPublished(details.getLangPublished());
			b.setManufacturer(details.getManufacturer());
			b.setMRP(details.getMRP());
			b.setOffer(details.getOffer());
			b.setPublicationYear(details.getPublicationYear());
			b.setQuantity(details.getQuantity());
			b.setSellingPrice(details.getSellingPrice());
			b.setUploadingDate(LocalDate.now());
			return new ResponseEntity<>(new ResponseDTO("Success","Book updated", bookRepo.save(b)), HttpStatus.OK);
		}
		return new ResponseEntity<>(new ResponseDTO("error", "Book id not Found", null), HttpStatus.NOT_FOUND);
	}

	@Override
	public ResponseEntity<?> removeBook(int bookId) {
		System.out.println("1 Delete book :" + bookId);
		Optional<Book> optional = bookRepo.findById(bookId);
		if (optional.isPresent()) {
			Book book = optional.get();

			System.out.println("2. list side --- ");
			Set<OrderList> list = book.getOrderList();
			list.forEach((l) -> {
				listService.removeOrderList(l.getId());
			});

			System.out.println("3. rating side --- ");
			Set<RatingAndReview> rate = book.getRatingReview();
			rate.forEach((r) -> {
				ratingService.removeRating(r.getId());
			});

			System.out.println("4. vendor side --- ");
			Vendor v = book.getVendor();
			v.getBooks().remove(book);
			vendorRepo.save(v);

			System.out.println("5 Doing ");
			bookRepo.delete(book);

			System.out.println("6 Book deleted successfully!");
			return new ResponseEntity<>("Book removed successfully!", HttpStatus.OK);
		}
		return new ResponseEntity<>(new ResponseDTO("error", "Book id not Found", null), HttpStatus.NOT_FOUND);

	}

}
