card view of book - catalogue
homepage - with ratings and offers
error handling
customer - cart and order
search book
add vendor bank, business details
rules and validation - adding book, login, 

Remaining : 

delete customer, vendor account -------- error
delete request not working
logout - login
rating and review


Optional :

Image
admin - cust ven data check
search by category
order history - vendor

------------------------------------------


Todays work - 
cust - order history ----- done
edit account and account details ------ done 
vendor - order history
rating 
styling ------ done
image
vendor is getting deleted if he has no books in his catalogue

----------------------------------------------

Today's task -

email - validation and order placed ------------ done
order confirmation time display delivery details message ------- done
image uploading
rating review
delete function ------ done with order list, book, vendor (address, business), customer (address)
admin




Remaining ------

image uploading  --- not done
delete account pop up
payment options --- not done
about us, faq, contact us, privacy policy  ---- not done