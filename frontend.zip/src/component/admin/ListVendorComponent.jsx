import React, { Component } from 'react'
import VendorService from "../../service/VendorService";

class ListVendorComponent extends Component {

    constructor(props) {
        super(props)
        this.state = {
            vendors: [],
            message: null
        }
        this.reloadVendorsList = this.reloadVendorsList.bind(this);
    }

    componentDidMount() {
        this.reloadVendorsList();
    }

    reloadVendorsList() {

        if(window.localStorage.getItem("adminId") === 'undefined') {
            this.props.history.push('/loginAdmin');
        }

        VendorService.fetchVendors()
            .then((res) => {
                console.log("check : ", res);
                this.setState({vendors: res.data.data});
            }).catch(error => {
                console.log("Got Error : ",error);
            });
    }

    showCustomers() {
        console.log("Redirecting to home : vendor logout");
        this.props.history.push('/showAllCust');
    }

    showVendors() {
        console.log("Redirecting to home : vendor logout");
        this.props.history.push('/showAllVendor');
    }

    logout() {
        console.log("Redirecting to home : vendor logout");
        window.localStorage.setItem("vendorId", undefined);

        console.log("Redirecting to home : customer logout");
        window.localStorage.setItem("customerId", undefined);

        console.log("Redirecting to home : admin logout");
        window.localStorage.setItem("adminId", undefined);

        this.props.history.push('/');
    }

    render() {

        return (
            <div>
                <div className="vendorAction">
                    <button className="vendorAction" onClick={() =>this.showCustomers()}>Our Customers</button>
                    <button className="vendorAction" onClick={() =>this.showVendors()}>Our Vendors</button>
                    <button className="vendorAction" onClick={() =>this.logout()}>Logout</button>
                </div>
                <h2 className="text-center">Vendor Details</h2>
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th>Vendor Id</th>
                            <th>Joining date</th>
                            <th>Name</th>
                            <th>Mobile No</th>
                            <th>Email</th>
                            <th>Company name</th>
                        </tr>
                    </thead>
                    
                    <tbody>
                        {
                            this.state.vendors.map(
                                vendor =>
                                    <tr key={vendor.id}>
                                        <td>#0200{vendor.id}</td>
                                        <td>{vendor.joiningDate}</td>
                                        <td>{vendor.firstName +" "+ vendor.lastName}</td>
                                        <td>+91 {vendor.mobileNo}</td>
                                        <td>{vendor.email}</td>
                                        <td>{vendor.businessDetails.companyName}</td>
                                    </tr>
                            )
                        }
                    </tbody>
                </table>

            </div>
        );
    }

}

export default ListVendorComponent;