import React, { Component } from 'react';

class LoginAdminComponent extends Component {

    constructor(props){
        super(props);
        this.state ={
            email: '',
            password: '',
            message: null
        }
        this.loginAdmin = this.loginAdmin.bind(this);
    };

    loginAdmin = (e) => {
        e.preventDefault();
        if(this.state.email === 'malgavepsm@gmail.com'){
            if(this.state.password === 'Poonam@123'){
                window.localStorage.setItem("adminId", '0807');
                alert("You have successfully logged in!");
                this.props.history.push('/');
            }
        }
        }

    onChange = (e) =>
    this.setState({ [e.target.name]: e.target.value });

    render() {
        return (
            <div className="login_form">
                <h2 className="text-center">Sign In as Admin</h2>
                    <form>

                        <div className="form-group">
                            <label>Email :</label>
                            <input type="text" name="email" className="form-control" value={this.state.email} required onChange={this.onChange}/>
                        </div>
    
                        <div className="form-group">
                            <label>Password:</label>
                            <input type="password" name="password" minLength="6" autoComplete="off" className="form-control" value={this.state.password} required onChange={this.onChange}/>
                        </div>
    
                        <button className="btn btn-success" onClick={this.loginAdmin}>Login</button>
                    </form>
 
                </div>       
            );
        }
}


export default LoginAdminComponent;