import React, { Component } from 'react'
import CustomerService from "../../service/CustomerService";

class ListCustomerComponent extends Component {

    constructor(props) {
        super(props)
        this.state = {
            customers: [],
            message: null
        }
        this.reloadCustomerList = this.reloadCustomerList.bind(this);
    }

    componentDidMount() {
        this.reloadCustomerList();
    }

    reloadCustomerList() {

        if(window.localStorage.getItem("adminId") === 'undefined') {
            this.props.history.push('/loginAdmin');
        }

        CustomerService.fetchCustomers()
            .then((res) => {
                console.log("check : ", res);
                this.setState({customers: res.data.data});
            }).catch(error => {
                console.log("Got Error : ",error);
            });
    }

    showCustomers() {
        console.log("Redirecting to home : vendor logout");
        this.props.history.push('/showAllCust');
    }

    showVendors() {
        console.log("Redirecting to home : vendor logout");
        this.props.history.push('/showAllVendor');
    }

    logout() {
        console.log("Redirecting to home : vendor logout");
        window.localStorage.setItem("vendorId", undefined);

        console.log("Redirecting to home : customer logout");
        window.localStorage.setItem("customerId", undefined);

        console.log("Redirecting to home : admin logout");
        window.localStorage.setItem("adminId", undefined);

        this.props.history.push('/');
    }

    render() {

        return (
            <div>
                <div className="vendorAction">
                    <button className="vendorAction" onClick={() =>this.showCustomers()}>Our Customers</button>
                    <button className="vendorAction" onClick={() =>this.showVendors()}>Our Vendors</button>
                    <button className="vendorAction" onClick={() =>this.logout()}>Logout</button>
                </div>
                <h2 className="text-center">Customer Details</h2>
                <table className="table table-striped">
                    <thead>
                        <tr>
                            <th>Customer Id</th>
                            <th>Joining date</th>
                            <th>Name</th>
                            <th>Mobile No</th>
                            <th>Email</th>
                        </tr>
                    </thead>
                    
                    <tbody>
                        {
                            this.state.customers.map(
                                customer =>
                                    <tr key={customer.id}>
                                        <td>#0100{customer.id}</td>
                                        <td>{customer.joiningDate}</td>
                                        <td>{customer.firstName} {customer.lastName}</td>
                                        <td>+91 {customer.mobileNo}</td>
                                        <td>{customer.email}</td>
                                    </tr>
                            )
                        }
                    </tbody>
                </table>

            </div>
        );
    }

}

export default ListCustomerComponent;