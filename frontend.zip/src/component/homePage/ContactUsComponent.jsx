import React, { Component } from 'react';

class ContactUsComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
            message: null
        }
    }

    showCustomers() {
        console.log("Redirecting to home : vendor logout");
        this.props.history.push('/showAllCust');
    }

    showVendors() {
        console.log("Redirecting to home : vendor logout");
        this.props.history.push('/showAllVendor');
    }

    logout() {
        console.log("Redirecting to home : vendor logout");
        window.localStorage.setItem("vendorId", undefined);

        console.log("Redirecting to home : customer logout");
        window.localStorage.setItem("customerId", undefined);

        console.log("Redirecting to home : admin logout");
        window.localStorage.setItem("adminId", undefined);

        this.props.history.push('/');
    }

    showOrderHistory() {
        console.log("Redirecting cust Order History");
        this.props.history.push('/custOrderHistory');
    }

    showCart() {
        console.log("Redirecting cust Order History");
        this.props.history.push('/showCart');
    }

    accountAction() {
        console.log("Redirecting cust Order History");
        this.props.history.push('/custAccountDetails');
    }

    addBook() {
        console.log("Redirecting to add new book");
        this.props.history.push('/addNewBook');
    }

    vendorAccount() {
        console.log("Redirecting to edit account");
        this.props.history.push('/vendorAccountDetails');
    }

    vendorCatalogue() {
        console.log("Redirecting to vendor catalogue account");
        this.props.history.push('/showVendorCatalogue');
    }


render() {

        let message
            if(window.localStorage.getItem("vendorId") !== 'undefined') {
                    message = <div className="vendorAction">
                    <button className="vendorAction" onClick={() =>this.vendorAccount()}>My Account</button>
                    <button className="vendorAction" onClick={() =>this.vendorCatalogue()}>My Catalogue</button>
                    <button className="vendorAction" onClick={() =>this.addBook()}>Add New Book</button>
                    <button className="vendorAction" onClick={() =>this.logout()}>Logout</button>
                    </div>
            } else if(window.localStorage.getItem("customerId") !== 'undefined') {
                    message = <div className="vendorAction">
                    <button className="vendorAction" onClick={() =>this.accountAction()}>My Account</button>
                    <button className="vendorAction" onClick={() =>this.showCart()}>My Cart</button>
                    <button className="vendorAction" onClick={() =>this.showOrderHistory()}>Order History</button>
                    <button className="vendorAction" onClick={() =>this.logout()}>Logout</button>
                    </div>
            } else if(window.localStorage.getItem("adminId") !== 'undefined') {
                    message = <div className="vendorAction">
                    <button className="vendorAction" onClick={() =>this.showCustomers()}>Our Customers</button>
                    <button className="vendorAction" onClick={() =>this.showVendors()}>Our Vendors</button>
                    <button className="vendorAction" onClick={() =>this.logout()}>Logout</button>
                    </div>
        } else {
                message = <div></div>
            }

        return (
            <div>
                <div>{message}</div>
                <h3 className="text-center">Contact us</h3>
                <div className="offers"> <img className="contactUs" src="/contactUs.jpg"  alt='Books1'></img></div>
                
                <p className="aboutCard">
                <p className="bookName">eBookStore</p>
                <p className="bookFormat">Company Name : eBookStore Pvt. Ltd.</p>
                <p className="bookFormat">Contact No : +91 1234567890</p>
                <p className="bookFormat">Email-Id : malgavepsm@gmail.com</p>
                <p className="bookFormat">Address : 603, DreamHigh Complex, Gangapur road, Nashik, Maharashtra, pincode - 422009.</p>
                <p className="bookFormat"></p>
                </p>

            </div>
        );
    }
}

export default ContactUsComponent;